#!/usr/bin/env python3
"""
aios_main.py - AIOS Pipeline Entry Point

Run the complete AIOS multi-agent pipeline to fix/build/update projects.

Usage:
    python aios_main.py --goal "Fix the test suite" --project-root .
    AIOS_EXECUTOR_MODE=frontier python aios_main.py --goal "..." --config config.json
"""

import sys
import argparse
import json
import os
from datetime import datetime

from aios_config import get_config, reset_config
from aios_coordinator import run_aios_pipeline


def setup_logging(verbose: bool = False):
    """Setup basic logging."""
    import logging
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="[%(asctime)s] %(levelname)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )


def validate_context(context: dict) -> bool:
    """Validate that context has required fields."""
    required = ["user_goal"]
    missing = [k for k in required if k not in context or not context[k]]
    if missing:
        print(f"[AIOS] Error: Missing required context fields: {missing}")
        return False
    return True


def save_result(result: dict, output_path: str):
    """Save pipeline result to JSON file."""
    try:
        with open(output_path, "w") as f:
            json.dump(result, f, indent=2, default=str)
        print(f"[AIOS] Result saved to: {output_path}")
    except Exception as e:
        print(f"[AIOS] Warning: Could not save result to {output_path}: {e}")


def main():
    parser = argparse.ArgumentParser(
        description="AIOS Multi-Agent Pipeline for Project Automation"
    )

    parser.add_argument(
        "--goal",
        type=str,
        help="User goal (what should be fixed/built/updated)"
    )
    
    parser.add_argument(
        "--context-json",
        type=str,
        help="JSON context from wrapper script (alternative to --goal)"
    )

    parser.add_argument(
        "--project-root",
        type=str,
        default=".",
        help="Root directory of the project (default: current directory)"
    )

    parser.add_argument(
        "--config",
        type=str,
        help="Path to AIOS config JSON file"
    )

    parser.add_argument(
        "--executor-mode",
        type=str,
        choices=["local", "frontier"],
        help="Override executor mode (local or frontier)"
    )

    parser.add_argument(
        "--max-iterations",
        type=int,
        help="Override max loop iterations"
    )

    parser.add_argument(
        "--output",
        type=str,
        help="Save result to JSON file"
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Verbose logging"
    )

    args = parser.parse_args()

    # ============================================================
    #  INITIALIZATION
    # ============================================================

    setup_logging(args.verbose)

    print("[AIOS] ========================================")
    print("[AIOS] AIOS Multi-Agent Pipeline")
    print(f"[AIOS] Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("[AIOS] ========================================\n")

    # Load configuration
    try:
        config = get_config(args.config)
        print(f"[AIOS] Configuration loaded")
    except Exception as e:
        print(f"[AIOS] Fatal: Could not load configuration: {e}")
        return 1

    # Override config with CLI args
    if args.executor_mode:
        config.set("executor_mode", args.executor_mode)
    if args.max_iterations:
        config.set("max_iterations", args.max_iterations)

    # ============================================================
    #  BUILD CONTEXT (from args or JSON)
    # ============================================================

    context = None

    # If context JSON provided (from wrapper), parse it
    if args.context_json:
        try:
            context = json.loads(args.context_json)
            print(f"[AIOS] Context loaded from wrapper")
        except json.JSONDecodeError as e:
            print(f"[AIOS] Error: Invalid context JSON: {e}")
            return 1
    
    # Otherwise build from CLI args
    else:
        if not args.goal:
            print("[AIOS] Error: Must provide --goal or --context-json")
            return 1

        context = {
            "user_goal": args.goal,
            "project_root": args.project_root,
            "log_excerpt": "",
        }

    # Add config to context
    context["executor_mode"] = config.get("executor_mode")
    context["max_iterations"] = config.get("max_iterations")

    # Ensure project_root exists
    project_root = context.get("project_root", args.project_root)
    if not os.path.isdir(project_root):
        print(f"[AIOS] Error: Project root not found: {project_root}")
        return 1

    # Change to project directory
    try:
        os.chdir(project_root)
        print(f"[AIOS] Working directory: {os.getcwd()}")
    except Exception as e:
        print(f"[AIOS] Error: Could not change to project root: {e}")
        return 1

    # Validate context
    if not validate_context(context):
        return 1

    print(f"[AIOS] Goal: {context.get('user_goal', 'unknown')}")
    print(f"[AIOS] Executor: {context.get('executor_mode', 'unknown')}")
    print(f"[AIOS] Max iterations: {context.get('max_iterations', 'unknown')}")
    print()

    # ============================================================
    #  RUN PIPELINE
    # ============================================================

    try:
        result = run_aios_pipeline(context)

        # Print summary
        print("\n[AIOS] ========================================")
        print(f"[AIOS] Status: {result.get('status', 'unknown')}")
        print(f"[AIOS] Iterations: {result.get('iteration', 'unknown')}")
        print("[AIOS] ========================================\n")

        # Save result if requested
        if args.output:
            save_result(result, args.output)

        # Return appropriate exit code
        if result.get("status") == "success":
            print("[AIOS] ✓ Pipeline completed successfully")
            return 0
        else:
            print("[AIOS] ✗ Pipeline completed without goal satisfaction")
            return 1

    except KeyboardInterrupt:
        print("\n[AIOS] ✗ Pipeline interrupted by user")
        return 130

    except Exception as e:
        print(f"\n[AIOS] ✗ Pipeline failed: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1

    finally:
        reset_config()


if __name__ == "__main__":
    sys.exit(main())
