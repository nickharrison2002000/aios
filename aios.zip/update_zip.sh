rm zip/*.zip
zip -r aios.zip . -x "llama.cpp/*" -x "llama.cpp" -x ".venv/*" -x ".venv" -x "__pycache__/*" -x "__pycache__"
mv *.zip zip

