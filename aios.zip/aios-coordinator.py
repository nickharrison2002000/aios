import os
import json
from llm_client import LLMClient
from coder_runtime import execute_plan

# ============================================================
#  GLOBAL PATHS & CONFIG
# ============================================================

AIOS_ROOT = os.getenv("AIOS_ROOT", "/usr/local/lib/aios")
PROMPT_DIR = os.path.join(AIOS_ROOT, "prompts")
MAX_ITERATIONS = int(os.getenv("AIOS_MAX_ITERATIONS", "5"))

def load_prompt(name: str) -> str:
    """Load a system prompt from the installed AIOS prompt directory."""
    path = os.path.join(PROMPT_DIR, name)
    
    if not os.path.exists(path):
        # Fallback defaults
        defaults = {
            "frontier_system_analyzer.txt": "You are Frontier System Analyzer. Analyze the system and create a detailed execution plan.",
            "frontier_coder_runner.txt": "You are Frontier Coder/Runner. Execute the plan and report results.",
        }
        
        if name in defaults:
            return defaults[name]
        else:
            raise FileNotFoundError(f"[AIOS] Missing prompt file: {path}")
    
    with open(path, "r") as f:
        return f.read()


# ============================================================
#  FRONTIER AGENT CALLS (2-agent system)
# ============================================================

def call_frontier_analyzer(context, llm_client: LLMClient):
    """
    Frontier System Analyzer: Analyzes context and creates execution plan.
    """
    system_prompt = load_prompt("frontier_system_analyzer.txt")
    try:
        return llm_client.run(system_prompt, context)
    except Exception as e:
        print(f"[FRONTIER] System Analyzer failed: {e}")
        raise


def call_frontier_coder_runner(plan, llm_client: LLMClient):
    """
    Frontier Coder/Runner: Executes the plan locally and reports results.
    """
    try:
        # Execute plan directly (no HTTP call, local executor)
        return execute_plan(plan)
    except Exception as e:
        print(f"[FRONTIER] Coder/Runner failed: {e}")
        raise


# ============================================================
#  MAIN FRONTIER PIPELINE (2-AGENT)
# ============================================================

def run_aios_pipeline(context):
    """
    AIOS 2-Agent Pipeline:
    1. Frontier System Analyzer: Analyzes and creates plan
    2. Frontier Coder/Runner: Executes and validates
    3. Loop if goal not satisfied
    
    This simplified 2-agent approach reduces:
    - JSON formatting issues (only 2 schemas instead of 4)
    - Latency (fewer LLM calls per iteration)
    - Complexity (simpler control flow)
    """

    user_goal = context.get("user_goal", "")

    if not user_goal:
        raise ValueError("[AIOS] No user_goal provided in context")

    # Initialize LLM client once
    print("[FRONTIER] Initializing Frontier System (local llama)...")
    llm_client = LLMClient()
    print("[FRONTIER] ✓ Frontier System initialized")
    print()

    iteration = 1
    plan = None
    execution_result = None
    goal_satisfied = False

    while iteration <= MAX_ITERATIONS:
        print(f"[FRONTIER] ========== Iteration {iteration} / {MAX_ITERATIONS} ==========")
        print()

        # ---- Phase 1: Analysis & Planning ----
        print("[FRONTIER] Phase 1: Analyzing context and creating plan...")
        try:
            plan = call_frontier_analyzer(context, llm_client)
            
            analysis = plan.get("analysis", {})
            print(f"[FRONTIER] ✓ Analysis complete")
            print(f"[FRONTIER]   - System: {analysis.get('system', 'unknown')}")
            print(f"[FRONTIER]   - Project Type: {analysis.get('project_type', 'unknown')}")
            if analysis.get("error_diagnosis"):
                print(f"[FRONTIER]   - Issue: {analysis.get('error_diagnosis')}")
            
            plan_summary = plan.get("plan", {}).get("summary", "")
            print(f"[FRONTIER]   - Plan: {plan_summary}")
            print()
            
        except Exception as e:
            print(f"[FRONTIER] ✗ Fatal: Analysis failed")
            raise

        # ---- Phase 2: Execution & Validation ----
        print("[FRONTIER] Phase 2: Executing plan and validating changes...")
        try:
            execution_result = call_frontier_coder_runner(plan, llm_client)
            status = execution_result.get("status", "unknown")
            print(f"[FRONTIER] ✓ Execution complete: {status}")
            
            # Show validation results
            validation = execution_result.get("validation", {})
            if validation:
                test_cmd = validation.get("test_command", "")
                exit_code = validation.get("exit_code", "?")
                passed = validation.get("passed", False)
                
                if test_cmd and test_cmd != "N/A":
                    print(f"[FRONTIER]   - Test: {test_cmd}")
                    print(f"[FRONTIER]   - Exit Code: {exit_code}")
                    print(f"[FRONTIER]   - Result: {'PASSED' if passed else 'FAILED'}")
                    
                    if validation.get("evidence"):
                        print(f"[FRONTIER]   - Evidence:")
                        for evidence in validation["evidence"][:3]:
                            print(f"[FRONTIER]     • {evidence}")
            
            # Check for errors
            if execution_result.get("errors"):
                print(f"[FRONTIER]   - Errors: {len(execution_result['errors'])}")
                for err in execution_result["errors"][:3]:
                    print(f"[FRONTIER]     • {err}")
            
            print()
            
        except Exception as e:
            print(f"[FRONTIER] ✗ Fatal: Execution failed")
            raise

        # ---- Evaluate Goal Satisfaction ----
        # Success criteria:
        # 1. Execution status is "success"
        # 2. Test validation passed (if test_command was run)
        # 3. No errors reported
        
        execution_status = execution_result.get("status", "unknown")
        validation = execution_result.get("validation", {})
        test_passed = validation.get("passed", False) if validation.get("test_command") and validation.get("test_command") != "N/A" else True
        no_errors = len(execution_result.get("errors", [])) == 0
        
        goal_satisfied = (execution_status == "success") and test_passed and no_errors
        
        if goal_satisfied:
            print(f"[FRONTIER] ✓✓✓ GOAL SATISFIED ✓✓✓")
            print()
            return {
                "status": "success",
                "iteration": iteration,
                "plan": plan,
                "execution_result": execution_result
            }
        
        # ---- Loop: Update context with results ----
        print("[FRONTIER] Goal not yet satisfied. Analyzing for next iteration...")
        
        # Update context with execution results for next iteration
        context["previous_plan"] = plan
        context["previous_execution"] = execution_result
        
        # Extract test output for next analysis
        if validation and validation.get("output"):
            context["log_excerpt"] = validation["output"]
        
        iteration += 1
        print()

    # ---- Max iterations reached ----
    print(f"[FRONTIER] ✗✗✗ MAX ITERATIONS ({MAX_ITERATIONS}) REACHED ✗✗✗")
    print()
    return {
        "status": "incomplete",
        "iteration": iteration,
        "plan": plan,
        "execution_result": execution_result
    }


if __name__ == "__main__":
    # Example usage
    context = {
        "project_root": ".",
        "executed_command": "npm test",
        "log_path": "example.log",
        "log_excerpt": "FAIL: add(3,3) expected 6 but got 9",
        "user_goal": "Fix the failing addition test",
        "environment": "Ubuntu 22.04",
        "tools": "npm, node, python3, git",
        "project_tree": "src/\n  utils.js\n  utils.test.js"
    }
    
    try:
        result = run_aios_pipeline(context)
        print("\n[FRONTIER] Final Result:")
        print(json.dumps({
            "status": result.get("status"),
            "iteration": result.get("iteration")
        }, indent=2))
    except Exception as e:
        print(f"\n[FRONTIER] Pipeline failed: {e}")
        exit(1)
