#!/usr/bin/env bash

set -e

echo "[AIOS] Removing AIOS installation..."

sudo rm -rf /usr/local/lib/aios
sudo rm -f /usr/local/bin/aios

echo "[AIOS] Uninstalled."
