# llm_client.py
import json
import os
from typing import Dict, Any, Optional

# Optional: llama.cpp bindings
try:
    from llama_cpp import Llama
except ImportError:
    Llama = None


class LLMClient:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize LLM client with local llama.cpp backend.
        
        Config options:
        {
            "llama_model": "/root/.cache/huggingface/hub/models--mradermacher--zephyr-7b-beta-absolute-heresy-i1-GGUF/snapshots/572e4cb0998d1926a51611eb4197bc8699cc1210/zephyr-7b-beta-absolute-heresy.i1-IQ4_NL.gguf",
            "llama_grammar": "/root/llama.cpp/grammars/english.gbnf",
            "llama_ctx": 4096,
            "llama_threads": 12
        }
        """
        self.config = config or self._load_default_config()
        self.local_llama_model = None

        # Load local llama model
        self._init_local_llama()

    def _load_default_config(self) -> Dict[str, Any]:
        """Load configuration from environment or use defaults."""
        return {
            "llama_model": os.getenv(
                "AIOS_LLAMA_MODEL",
                "/root/.cache/huggingface/hub/models--mradermacher--zephyr-7b-beta-absolute-heresy-i1-GGUF/snapshots/572e4cb0998d1926a51611eb4197bc8699cc1210/zephyr-7b-beta-absolute-heresy.i1-IQ4_NL.gguf"
            ),
            "llama_grammar": os.getenv(
                "AIOS_LLAMA_GRAMMAR",
                "/root/llama.cpp/grammars/english.gbnf"
            ),
            "llama_ctx": int(os.getenv("AIOS_LLAMA_CTX", "4096")),
            "llama_threads": int(os.getenv("AIOS_LLAMA_THREADS", "12"))
        }

    def _init_local_llama(self):
        """Initialize local llama.cpp model."""
        if not Llama:
            raise RuntimeError(
                "llama-cpp-python is required but not installed. "
                "Install with: pip install llama-cpp-python"
            )

        config = self.config
        model_path = config["llama_model"]
        grammar_path = config["llama_grammar"]

        # Validate paths exist
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Llama model not found at {model_path}")

        if not os.path.exists(grammar_path):
            raise FileNotFoundError(f"Llama grammar not found at {grammar_path}")

        try:
            # Load grammar file
            with open(grammar_path, "r") as f:
                grammar_text = f.read()

            # Initialize llama.cpp with grammar
            print(f"[LLMClient] Loading model: {model_path}")
            self.local_llama_model = Llama(
                model_path=model_path,
                n_ctx=config["llama_ctx"],
                n_threads=config["llama_threads"],
                grammar=grammar_text,
                chat_format="completion"
            )
            print(f"[LLMClient] Model loaded successfully")

        except Exception as e:
            raise RuntimeError(f"Failed to initialize local llama: {e}")

    # ---------------------------------------------------------
    # PUBLIC API
    # ---------------------------------------------------------

    def run(self, system_prompt: str, user_payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run inference using local llama.cpp model.
        
        Args:
            system_prompt: system context
            user_payload: user input (dict)
        
        Returns:
            Parsed JSON response as dict
        """
        if not self.local_llama_model:
            raise RuntimeError("Local llama model not initialized")

        response_text = self._run_inference(system_prompt, user_payload)
        return self._extract_json(response_text)

    # ---------------------------------------------------------
    # BACKEND: Local llama.cpp
    # ---------------------------------------------------------

    def _run_inference(self, system_prompt: str, user_payload: Dict[str, Any]) -> str:
        """
        Run inference using local llama.cpp model.
        """
        prompt = (
            system_prompt
            + "\n\n"
            + json.dumps(user_payload, indent=2)
            + "\n\nReturn ONLY a single JSON object. No explanations."
        )

        try:
            output = self.local_llama_model(
                prompt,
                max_tokens=25000,
                temperature=0.2,
            )
            return output["choices"][0]["text"]
        except Exception as e:
            raise RuntimeError(f"Local llama inference failed: {e}")

    # ---------------------------------------------------------
    # HELPERS
    # ---------------------------------------------------------

    def _extract_json(self, text: str) -> Dict[str, Any]:
        """
        Extract the first valid JSON object from text.
        Handles various edge cases (nested objects, escaped quotes, etc).
        """
        if not text or not isinstance(text, str):
            raise ValueError(f"Invalid response text: {type(text)}")

        text = text.strip()

        # Try direct parsing first (entire response is JSON)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        # Find and extract first JSON object
        depth = 0
        start_idx = -1
        end_idx = -1

        for i, char in enumerate(text):
            if char == '{':
                if depth == 0:
                    start_idx = i
                depth += 1
            elif char == '}':
                depth -= 1
                if depth == 0 and start_idx >= 0:
                    end_idx = i + 1
                    break

        if start_idx >= 0 and end_idx > start_idx:
            try:
                json_str = text[start_idx:end_idx]
                return json.loads(json_str)
            except json.JSONDecodeError as e:
                raise ValueError(f"Extracted JSON is invalid: {e}\nExtracted: {json_str}")

        raise ValueError(
            f"Could not extract valid JSON from response.\nResponse preview: {text[:200]}"
        )


if __name__ == "__main__":
    # Test initialization
    try:
        client = LLMClient()
        print("[LLMClient] Initialized successfully")
    except Exception as e:
        print(f"[LLMClient] Error: {e}")
