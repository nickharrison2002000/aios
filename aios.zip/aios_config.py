"""
aios_config.py - AIOS Configuration and Environment Setup

This module provides centralized configuration management for the AIOS system.
It loads configuration from environment variables, config files, and provides defaults.
"""

import os
import json
from typing import Dict, Any, Optional


class AIoSConfig:
    """Central configuration manager for AIOS."""

    # ============================================================
    #  DEFAULTS
    # ============================================================

    DEFAULTS = {
        # System paths
        "aios_root": "/usr/local/lib/aios",
        "prompt_dir": None,  # Set to {aios_root}/prompts if None
        "backup_dir": ".aios/backups",
        "log_dir": ".aios/logs",

        # LLM backend (local llama.cpp only)
        "executor_mode": "local",
        "max_iterations": 5,

        # Local llama configuration
        "llama_model": "/root/gemma-4-26B-A4B-it-ara-abliterated/gemma4-ara-2pass-APEX-Q5_K_M.gguf",
        "llama_grammar": "/root/llama.cpp/grammars/json.gbnf",
        "llama_ctx": 4096,
        "llama_threads": 6,

        # Logging
        "log_level": "INFO",
        "verbose": False,
    }

    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize configuration from defaults, environment, and config file.

        Args:
            config_file: Path to JSON config file (optional)
        """
        self.config = self.DEFAULTS.copy()

        # Load from environment
        self._load_from_env()

        # Load from config file
        if config_file and os.path.exists(config_file):
            self._load_from_file(config_file)

        # Resolve derived paths
        self._resolve_paths()

    def _load_from_env(self):
        """Load configuration from environment variables."""
        env_mapping = {
            "AIOS_ROOT": "aios_root",
            "AIOS_PROMPT_DIR": "prompt_dir",
            "AIOS_BACKUP_DIR": "backup_dir",
            "AIOS_LOG_DIR": "log_dir",
            "AIOS_MAX_ITERATIONS": ("max_iterations", int),
            "AIOS_LLAMA_MODEL": "llama_model",
            "AIOS_LLAMA_GRAMMAR": "llama_grammar",
            "AIOS_LLAMA_CTX": ("llama_ctx", int),
            "AIOS_LLAMA_THREADS": ("llama_threads", int),
            "AIOS_LOG_LEVEL": "log_level",
            "AIOS_VERBOSE": ("verbose", lambda x: x.lower() in ("true", "1", "yes")),
        }

        for env_var, config_key in env_mapping.items():
            val = os.getenv(env_var)
            if val is not None:
                if isinstance(config_key, tuple):
                    key, converter = config_key
                    self.config[key] = converter(val)
                else:
                    self.config[config_key] = val

    def _load_from_file(self, config_file: str):
        """Load configuration from JSON file."""
        try:
            with open(config_file, "r") as f:
                file_config = json.load(f)
                self.config.update(file_config)
        except Exception as e:
            print(f"[AIoSConfig] Warning: Could not load config file {config_file}: {e}")

    def _resolve_paths(self):
        """Resolve derived paths."""
        if self.config["prompt_dir"] is None:
            self.config["prompt_dir"] = os.path.join(
                self.config["aios_root"], "prompts"
            )

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value."""
        return self.config.get(key, default)

    def set(self, key: str, value: Any):
        """Set configuration value."""
        self.config[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """Get all configuration as dict."""
        return self.config.copy()

    def to_llm_client_config(self) -> Dict[str, Any]:
        """Convert to LLMClient config format."""
        return {
            "llama_model": self.config["llama_model"],
            "llama_grammar": self.config["llama_grammar"],
            "llama_ctx": self.config["llama_ctx"],
            "llama_threads": self.config["llama_threads"]
        }

    def __repr__(self) -> str:
        """String representation."""
        return f"AIoSConfig({len(self.config)} settings)"


# Global singleton
_config_instance = None


def get_config(config_file: Optional[str] = None) -> AIoSConfig:
    """Get or create global config instance."""
    global _config_instance
    if _config_instance is None:
        _config_instance = AIoSConfig(config_file)
    return _config_instance


def reset_config():
    """Reset global config instance."""
    global _config_instance
    _config_instance = None


if __name__ == "__main__":
    config = get_config()
    print("AIOS Configuration:")
    for key, value in config.to_dict().items():
        # Hide sensitive paths
        if "path" in key.lower() or "model" in key.lower():
            if isinstance(value, str) and len(value) > 50:
                print(f"  {key}: {value[:40]}...")
            else:
                print(f"  {key}: {value}")
        else:
            print(f"  {key}: {value}")
