import os
import json
import subprocess
import time
import random
from datetime import datetime
from typing import Dict, Any, List, Tuple


# ============================================================
#  RESILIENCE & ERROR HANDLING
# ============================================================

class RetryConfig:
    """Configuration for retry logic with exponential backoff"""
    
    def __init__(self, max_retries=3, base_delay=1, max_delay=32):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
    
    def get_delay(self, attempt: int) -> float:
        """Calculate exponential backoff with jitter"""
        delay = min(self.base_delay * (2 ** attempt), self.max_delay)
        jitter = delay * 0.1 * (random.random() - 0.5)
        return max(delay + jitter, 0.1)


class ErrorClassification:
    """Classify errors as retriable or terminal"""
    
    RETRIABLE = {
        "timeout",
        "connection_reset",
        "rate_limit",
        "temporarily_unavailable",
        "busy",
        "econnrefused",
        "econnreset",
        "broken pipe",
    }
    
    TERMINAL = {
        "file_not_found",
        "permission_denied",
        "syntax_error",
        "schema_mismatch",
        "invalid_argument",
        "no such file",
        "access denied",
    }
    
    @staticmethod
    def classify(error: Exception) -> str:
        """Return 'retriable', 'terminal', or 'unknown'"""
        error_str = str(error).lower()
        
        for key in ErrorClassification.RETRIABLE:
            if key in error_str:
                return "retriable"
        
        for key in ErrorClassification.TERMINAL:
            if key in error_str:
                return "terminal"
        
        return "unknown"


def run_with_retry(func, config: RetryConfig, *args, **kwargs):
    """Execute function with exponential backoff retry"""
    last_error = None
    
    for attempt in range(config.max_retries):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            last_error = e
            classification = ErrorClassification.classify(e)
            
            if classification == "terminal":
                # Don't retry terminal errors
                raise
            
            if attempt < config.max_retries - 1:
                delay = config.get_delay(attempt)
                print(f"[CODER] Retry attempt {attempt+1}/{config.max_retries} in {delay:.1f}s... ({classification})")
                time.sleep(delay)
            else:
                print(f"[CODER] All {config.max_retries} retry attempts exhausted")
    
    raise last_error


# ============================================================
#  FILE OPERATIONS WITH RESILIENCE
# ============================================================

BACKUP_DIR = ".aios/backups"
LOG_DIR = ".aios/logs"
DISCOVERY_DIR = ".aios/discovery"


def ensure_dirs():
    """Create necessary directories"""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(DISCOVERY_DIR, exist_ok=True)


def backup_file(path: str) -> str:
    """
    Save a backup of the file before modification.
    Returns the backup path, or empty string if file doesn't exist.
    """
    ensure_dirs()

    if not os.path.exists(path):
        return ""

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(BACKUP_DIR, f"{path.replace('/', '_')}_{timestamp}.bak")

    os.makedirs(os.path.dirname(backup_path), exist_ok=True)

    try:
        with open(path, "r") as src, open(backup_path, "w") as dst:
            dst.write(src.read())
        return backup_path
    except Exception as e:
        print(f"[CODER] Warning: Could not backup {path}: {e}")
        return ""


def validate_operation(operation: Dict) -> Tuple[bool, str]:
    """Validate operation before execution for safety"""
    
    action = operation.get("action", "")
    
    # Validate delete operations
    if action == "delete":
        file = operation.get("file", "")
        
        if file in ["/", ".", "..", "*"]:
            return False, "Cannot delete root or ambiguous paths"
        
        if file.endswith("/*") or file.count("/") > 5:
            return False, "Recursive delete patterns are too dangerous"
    
    # Validate create operations
    if action == "create":
        file = operation.get("file", "")
        
        if file.startswith("/usr") or file.startswith("/etc") or file.startswith("/sys"):
            return False, "Cannot create in system directories"
    
    # Validate code snippets
    code = operation.get("code", "")
    if "rm -rf /" in code:
        return False, "Shell code contains dangerous rm -rf pattern"
    
    if "exec(" in code or "eval(" in code:
        return False, "Code contains exec/eval (execution risk)"
    
    return True, "OK"


def run_discovery_command(cmd: str, reason: str) -> Dict[str, Any]:
    """
    Run a discovery command to learn about tools or read files.
    Save output for later reference.
    """
    ensure_dirs()
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(DISCOVERY_DIR, f"discovery_{timestamp}.txt")
    
    print(f"[DISCOVERY] Running: {cmd}")
    print(f"[DISCOVERY] Reason: {reason}")
    
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        output = result.stdout + result.stderr
        
        # Save discovery output
        with open(output_file, "w") as f:
            f.write(f"Command: {cmd}\n")
            f.write(f"Reason: {reason}\n")
            f.write(f"Exit Code: {result.returncode}\n")
            f.write(f"Output:\n{output}\n")
        
        # Print first 50 lines of output
        lines = output.split("\n")
        for line in lines[:50]:
            print(f"[DISCOVERY]   {line}")
        
        if len(lines) > 50:
            print(f"[DISCOVERY]   ... ({len(lines) - 50} more lines, see {output_file})")
        
        return {
            "command": cmd,
            "reason": reason,
            "exit_code": result.returncode,
            "output": output,
            "output_file": output_file
        }
        
    except subprocess.TimeoutExpired:
        print(f"[DISCOVERY] ✗ Command timed out after 30 seconds")
        return {
            "command": cmd,
            "reason": reason,
            "exit_code": -1,
            "output": "Command timed out",
            "output_file": output_file
        }
    except Exception as e:
        print(f"[DISCOVERY] ✗ Command failed: {e}")
        return {
            "command": cmd,
            "reason": reason,
            "exit_code": -1,
            "output": str(e),
            "output_file": output_file
        }


def apply_read(path: str) -> str:
    """Read and return file contents"""
    
    if not os.path.exists(path):
        raise FileNotFoundError(f"Cannot read missing file: {path}")
    
    try:
        with open(path, "r") as f:
            content = f.read()
        
        print(f"[CODER] Read {len(content)} bytes from {path}")
        return content
    except Exception as e:
        raise IOError(f"Failed to read {path}: {e}")


def apply_modify_replace(path: str, search: str, replace_with: str):
    """Replace exact text in file"""
    
    if not os.path.exists(path):
        raise FileNotFoundError(f"Cannot modify missing file: {path}")

    with open(path, "r") as f:
        original = f.read()

    if search not in original:
        raise ValueError(f"Search text not found in {path}")

    new_content = original.replace(search, replace_with)
    
    with open(path, "w") as f:
        f.write(new_content)


def apply_modify_append(path: str, code: str):
    """Append code to file"""
    
    if not os.path.exists(path):
        raise FileNotFoundError(f"Cannot modify missing file: {path}")

    with open(path, "a") as f:
        f.write("\n\n" + code)


def apply_create(path: str, code: str):
    """Create a new file with code"""
    
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

    try:
        with open(path, "w") as f:
            f.write(code)
    except Exception as e:
        raise IOError(f"Failed to create {path}: {e}")


def apply_delete(path: str):
    """Delete a file"""
    
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception as e:
            raise IOError(f"Failed to delete {path}: {e}")


# ============================================================
#  RUNTIME EXECUTION WITH RESILIENCE
# ============================================================

def run_runtime_command(cmd: str) -> Dict[str, Any]:
    """
    Run the runtime command, stream logs, and save to file.
    Returns structured run information with resilience.
    """
    ensure_dirs()

    if not cmd or not cmd.strip():
        return {
            "command": "",
            "exit_code": 0,
            "output": "",
            "duration_seconds": 0.0
        }

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(LOG_DIR, f"run_{timestamp}.log")

    start_time = time.time()
    exit_code = -1
    output_lines = []

    try:
        with open(log_path, "w") as log:
            print(f"[CODER] Running: {cmd}")
            
            process = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )

            for line in iter(process.stdout.readline, ''):
                if line:
                    print(line, end="")
                    log.write(line)
                    output_lines.append(line)

            exit_code = process.wait()

    except Exception as e:
        with open(log_path, "a") as log:
            log.write(f"\n[ERROR] Command execution failed: {e}\n")
        exit_code = -1

    end_time = time.time()

    # Get last 200 lines of output
    output = "".join(output_lines[-200:]) if output_lines else ""

    return {
        "command": cmd,
        "exit_code": exit_code,
        "output": output,
        "duration_seconds": round(end_time - start_time, 3)
    }


# ============================================================
#  MAIN ENTRYPOINT — EXECUTE EXECUTIONPLAN
# ============================================================

def execute_plan(plan: Dict[str, Any]) -> Dict[str, Any]:
    """
    Execute discovery phase, apply file operations, and run test command.
    
    Plan structure:
    {
        "summary": "what this plan does",
        "discovery": [
            {
                "command": "tool --help",
                "reason": "why we need to run this"
            }
        ],
        "steps": [
            {
                "file": "path/to/file",
                "action": "create|replace|append|delete|read",
                "code": "code for create/append",
                "search": "text to search (for replace)",
                "with": "replacement text (for replace)"
            }
        ],
        "test_command": "npm test"
    }
    
    Returns CoderResult:
    {
        "status": "success|failed",
        "discovery_results": [ ... ],
        "applied": [ ... ],
        "test": { ... },
        "errors": [ ... ]
    }
    """
    ensure_dirs()

    applied = []
    errors = []
    discovery_results = []
    retry_config = RetryConfig(max_retries=3)

    # ====== PHASE 0: Discovery (Learn about tools and read files) ======
    discovery_commands = plan.get("discovery", [])
    
    if discovery_commands:
        print("\n[CODER] ========== Discovery Phase ==========")
        
        for discovery in discovery_commands:
            cmd = discovery.get("command", "")
            reason = discovery.get("reason", "")
            
            if not cmd:
                continue
            
            result = run_discovery_command(cmd, reason)
            discovery_results.append(result)
        
        print("[CODER] ========== Discovery Complete ==========\n")

    # ====== PHASE 1: Apply file operations with resilience ======
    for step in plan.get("steps", []):
        file = step.get("file", "")
        action = step.get("action", "")

        if not file or not action:
            continue

        print(f"[CODER] Processing: {file}")

        # Validate operation for safety
        safe, reason = validate_operation(step)
        if not safe:
            error_msg = f"Operation validation failed: {reason}"
            errors.append(error_msg)
            applied.append({
                "file": file,
                "result": "skipped",
                "reason": reason
            })
            print(f"[CODER]   ✗ BLOCKED: {reason}")
            continue

        before = backup_file(file) if action in ["replace", "append"] else ""

        try:
            # Execute with retry on transient failures
            def execute_step():
                if action == "read":
                    content = apply_read(file)
                    # Store read content in discovery
                    discovery_results.append({
                        "command": f"cat {file}",
                        "reason": "Read file contents",
                        "exit_code": 0,
                        "output": content[:1000] + ("..." if len(content) > 1000 else ""),
                        "output_file": "inline"
                    })
                elif action == "replace":
                    search = step.get("search", "")
                    with_text = step.get("with", "")
                    apply_modify_replace(file, search, with_text)
                elif action == "append":
                    code = step.get("code", "")
                    apply_modify_append(file, code)
                elif action == "create":
                    code = step.get("code", "")
                    apply_create(file, code)
                elif action == "delete":
                    apply_delete(file)
                else:
                    raise ValueError(f"Unknown action: {action}")

            run_with_retry(execute_step, retry_config)

            applied.append({
                "file": file,
                "result": action,
                "backup": before if before else None
            })

            print(f"[CODER]   ✓ {action.upper()}: {file}")

        except Exception as e:
            error_msg = f"Failed to {action} {file}: {e}"
            errors.append(error_msg)
            applied.append({
                "file": file,
                "result": "failed",
                "error": str(e)
            })
            print(f"[CODER]   ✗ {error_msg}")

    # ====== PHASE 2: Run test command ====== 
    test_cmd = plan.get("test_command", "")
    test_result = run_runtime_command(test_cmd)

    # ====== BUILD RESULT ======
    status = "success"
    if errors:
        status = "failed"
        print(f"\n[CODER] {len(errors)} error(s) during file operations:")
        for err in errors:
            print(f"  - {err}")
    
    if test_result["exit_code"] != 0:
        status = "failed"
        print(f"\n[CODER] Test command failed with exit code {test_result['exit_code']}")

    return {
        "status": status,
        "discovery_results": discovery_results,
        "applied": applied,
        "test": {
            "command": test_result["command"],
            "exit_code": test_result["exit_code"],
            "output": test_result["output"]
        },
        "errors": errors
    }


if __name__ == "__main__":
    # Example execution
    sample_plan = {
        "summary": "Test discovery and file creation",
        "discovery": [
            {
                "command": "ls --help",
                "reason": "Learn ls options"
            }
        ],
        "steps": [
            {
                "file": "test_output.txt",
                "action": "create",
                "code": "# Test output\nGenerated by AIOS\n"
            }
        ],
        "test_command": "cat test_output.txt"
    }

    result = execute_plan(sample_plan)
    print("\n[CODER] Result:")
    print(json.dumps({
        "status": result["status"],
        "discovery": len(result["discovery_results"]),
        "applied": len(result["applied"]),
        "errors": result["errors"]
    }, indent=2))
