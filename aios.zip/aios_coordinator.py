import os
import json
from llm_client import LLMClient
from coder_runtime import execute_plan

# ============================================================
#  GLOBAL PATHS & CONFIG
# ============================================================

AIOS_ROOT = os.getenv("AIOS_ROOT", "/usr/local/lib/aios")
PROMPT_DIR = os.path.join(AIOS_ROOT, "prompts")
MAX_ITERATIONS = int(os.getenv("AIOS_MAX_ITERATIONS", "5"))

def load_prompt(name: str) -> str:
    """
    Load a system prompt from the installed AIOS prompt directory.
    Falls back to inline defaults if not found.
    """
    path = os.path.join(PROMPT_DIR, name)
    
    if not os.path.exists(path):
        # Fallback defaults (minimal)
        defaults = {
            "frontier_project_identifier.txt": "You are the Project Identifier Agent. Analyze the project and output JSON with: languages, frameworks, entrypoints, key_contracts, recommended_runtime.",
            "frontier_reasoner.txt": "You are the Reasoner Agent. Given project, user_goal, and logs, produce a JSON ExecutionPlan with: summary, steps (file, action, search/code, with/replace_with), test_command.",
            "frontier_coder.txt": "You are the Coder Agent. Execute the ExecutionPlan: modify files, create files, delete files, run test command. Return JSON CoderResult with: status, applied, test.",
            "frontier_analyzer.txt": "You are the Analyzer Agent. Determine if the goal is satisfied. Return JSON with: satisfied, reason, next_steps."
        }
        
        if name in defaults:
            return defaults[name]
        else:
            raise FileNotFoundError(f"[AIOS] Missing prompt file: {path}")
    
    with open(path, "r") as f:
        return f.read()


# ============================================================
#  FRONTIER AGENT CALLS (All using same local llama instance)
# ============================================================

def call_frontier_project_identifier(context, llm_client: LLMClient):
    """
    Frontier acting as Project Identifier Agent.
    Analyzes project structure.
    """
    system_prompt = load_prompt("frontier_project_identifier.txt")
    try:
        return llm_client.run(system_prompt, context)
    except Exception as e:
        print(f"[FRONTIER] Project Identifier phase failed: {e}")
        raise


def call_frontier_reasoner(project, user_goal, log_excerpt, llm_client: LLMClient):
    """
    Frontier acting as Reasoner Agent.
    Creates ExecutionPlan from project profile and goal.
    """
    system_prompt = load_prompt("frontier_reasoner.txt")
    payload = {
        "project": project,
        "goal": user_goal,
        "logs": log_excerpt
    }
    try:
        return llm_client.run(system_prompt, payload)
    except Exception as e:
        print(f"[FRONTIER] Reasoner phase failed: {e}")
        raise


def call_frontier_coder(execution_plan, llm_client: LLMClient):
    """
    Frontier acting as Coder Agent.
    Executes the ExecutionPlan locally.
    """
    try:
        # Execute plan directly (Frontier doesn't call HTTP, it calls local executor)
        return execute_plan(execution_plan)
    except Exception as e:
        print(f"[FRONTIER] Coder phase failed: {e}")
        raise


def call_frontier_analyzer(goal, execution_result, llm_client: LLMClient):
    """
    Frontier acting as Analyzer Agent.
    Evaluates goal satisfaction.
    """
    system_prompt = load_prompt("frontier_analyzer.txt")
    payload = {
        "goal": goal,
        "execution": execution_result
    }
    try:
        return llm_client.run(system_prompt, payload)
    except Exception as e:
        print(f"[FRONTIER] Analyzer phase failed: {e}")
        raise


# ============================================================
#  MAIN FRONTIER PIPELINE
# ============================================================

def run_aios_pipeline(context):
    """
    Full AIOS multi-agent pipeline using Frontier (single local llama model).
    Frontier assumes all four roles: Identifier, Reasoner, Coder, Analyzer.
    
    Flow:
      1. Project Identifier → ProjectProfile
      2. Loop (max MAX_ITERATIONS):
        a. Reasoner → ExecutionPlan
        b. Coder → CoderResult
        c. Analyzer → Analysis
        d. If goal_satisfied, return; else loop with gaps
    """

    user_goal = context.get("user_goal", "")
    log_excerpt = context.get("log_excerpt", "")

    if not user_goal:
        raise ValueError("[AIOS] No user_goal provided in context")

    # Initialize LLM client once (persistent model across all phases)
    print("[FRONTIER] Initializing Frontier (local llama)...")
    llm_client = LLMClient()
    print("[FRONTIER] Frontier initialized")

    # --------------------------------------------------------
    # 1. Project Identifier (Frontier Phase 1)
    # --------------------------------------------------------
    print("\n[FRONTIER] Phase 1: Project Identification")
    try:
        project_profile = call_frontier_project_identifier(context, llm_client)
        print(f"[FRONTIER] ✓ Project identified: {project_profile.get('languages', ['unknown'])[0]}")
    except Exception as e:
        print(f"[FRONTIER] ✗ Fatal: Project Identification failed")
        raise

    # --------------------------------------------------------
    # LOOP UNTIL GOAL SATISFIED OR MAX ITERATIONS
    # --------------------------------------------------------
    iteration = 1
    execution_plan = None
    coder_result = None
    analysis = None

    while iteration <= MAX_ITERATIONS:
        print(f"\n[FRONTIER] ========== Iteration {iteration} / {MAX_ITERATIONS} ==========")

        # -------- Phase 2: Reasoner --------
        print("[FRONTIER] Phase 2: Reasoning & Planning")
        try:
            execution_plan = call_frontier_reasoner(
                project_profile, 
                user_goal, 
                log_excerpt,
                llm_client
            )
            plan_summary = execution_plan.get("summary", "")
            print(f"[FRONTIER] ✓ Plan created: {plan_summary}")
        except Exception as e:
            print(f"[FRONTIER] ✗ Fatal: Reasoner phase failed")
            raise

        # -------- Phase 3: Coder --------
        print("[FRONTIER] Phase 3: Execution")
        try:
            coder_result = call_frontier_coder(execution_plan, llm_client)
            status = coder_result.get("status", "unknown")
            print(f"[FRONTIER] ✓ Coder status: {status}")
            
            # Log errors if any
            if coder_result.get("errors"):
                print(f"[FRONTIER] Coder reported {len(coder_result['errors'])} error(s) during execution")
        except Exception as e:
            print(f"[FRONTIER] ✗ Fatal: Coder phase failed")
            raise

        # -------- Phase 4: Analyzer --------
        print("[FRONTIER] Phase 4: Analysis & Evaluation")
        try:
            # Build execution result for analyzer
            execution_result = {
                "status": coder_result.get("status", "unknown"),
                "applied": coder_result.get("applied", []),
                "test": coder_result.get("test", {}),
                "errors": coder_result.get("errors", [])
            }
            
            analysis = call_frontier_analyzer(user_goal, execution_result, llm_client)
            goal_satisfied = analysis.get("satisfied", False)
            reason = analysis.get("reason", "")
            print(f"[FRONTIER] ✓ Analysis complete")
            print(f"[FRONTIER] Goal satisfied: {goal_satisfied}")
            if reason:
                print(f"[FRONTIER] Reason: {reason}")
        except Exception as e:
            print(f"[FRONTIER] ✗ Fatal: Analyzer phase failed")
            raise

        # -------- Check completion --------
        if goal_satisfied:
            print(f"\n[FRONTIER] ✓✓✓ GOAL SATISFIED ✓✓✓")
            return {
                "status": "success",
                "iteration": iteration,
                "project_profile": project_profile,
                "execution_plan": execution_plan,
                "coder_result": coder_result,
                "analysis": analysis
            }

        # -------- Loop: Update context with next steps --------
        next_steps = analysis.get("next_steps", [])
        if next_steps:
            print(f"\n[FRONTIER] {len(next_steps)} next step(s) identified:")
            for step in next_steps:
                print(f"  - {step}")
            context["next_steps"] = next_steps
        else:
            print("[FRONTIER] ⚠ No next steps found but goal not satisfied. Possible infinite loop.")
            print("[FRONTIER] Attempting another iteration...")

        # Extract updated log excerpt from coder result
        try:
            if coder_result.get("test") and coder_result["test"].get("output"):
                log_excerpt = coder_result["test"]["output"]
        except Exception:
            pass

        # Re-identify project after successful execution to get updated profile
        if coder_result.get("status") == "success":
            try:
                print("[FRONTIER] Re-identifying project after changes...")
                project_profile = call_frontier_project_identifier(context, llm_client)
            except Exception as e:
                print(f"[FRONTIER] Warning: Could not re-identify project: {e}")
                # Continue with old profile

        iteration += 1

    # -------- Max iterations reached --------
    print(f"\n[FRONTIER] ✗✗✗ MAX ITERATIONS ({MAX_ITERATIONS}) REACHED WITHOUT GOAL SATISFACTION ✗✗✗")
    return {
        "status": "incomplete",
        "iteration": iteration,
        "project_profile": project_profile,
        "execution_plan": execution_plan,
        "coder_result": coder_result,
        "analysis": analysis
    }


if __name__ == "__main__":
    # Example usage
    context = {
        "user_goal": "Fix the test suite and ensure all tests pass",
        "log_excerpt": "Test run output...",
        "project_root": "."
    }
    
    try:
        result = run_aios_pipeline(context)
        print("\n[FRONTIER] Final result:")
        print(json.dumps({
            "status": result.get("status"),
            "iteration": result.get("iteration"),
            "goal_satisfied": result.get("analysis", {}).get("satisfied")
        }, indent=2))
    except Exception as e:
        print(f"\n[FRONTIER] Pipeline failed: {e}")
        exit(1)
