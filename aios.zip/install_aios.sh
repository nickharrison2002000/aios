#!/usr/bin/env bash

# AIOS Installation Script
# Installs AIOS 2-Agent Full Frontier system to /usr/local/lib/aios
#
# Expected directory structure (this script should be in the root):
# .
# ├── .aios/                    (local runtime - not copied)
# │   ├── backups/
# │   ├── logs/
# │   └── discovery/
# ├── aios                      (wrapper script)
# ├── aios_main.py
# ├── aios_config.py
# ├── aios_coordinator.py
# ├── coder_runtime.py
# ├── llm_client.py
# ├── install_aios.sh
# ├── prompts/                  (2 prompt files for 2-agent system)
# │   ├── frontier_system_analyzer.txt
# │   └── frontier_coder_runner.txt
# └── examples/
#     ├── example_scenario_basic_fix.txt
#     ├── example_scenario_error_recovery.txt
#     ├── example_scenario_kvm_research.txt
#     └── example_scenario_validation_testing.txt

set -e

AIOS_HOME="/usr/local/lib/aios"
BIN_PATH="/usr/local/bin/aios"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[INSTALL] AIOS 2-Agent Frontier System Installation"
echo "[INSTALL] Source directory: $SCRIPT_DIR"
echo ""

# ============================================================
#  Validate Python
# ============================================================

echo "[INSTALL] Checking Python..."
if ! command -v python3 &> /dev/null; then
    echo "[INSTALL] ✗ Error: python3 not found. Please install Python 3.8+"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
echo "[INSTALL] ✓ Found Python $PYTHON_VERSION"
echo ""

# ============================================================
#  Validate source directory structure
# ============================================================

echo "[INSTALL] Validating source directory structure..."

# Check required Python files in root
REQUIRED_PYTHON_FILES=(
    "aios_main.py"
    "aios_config.py"
    "aios_coordinator.py"
    "coder_runtime.py"
    "llm_client.py"
    "aios"
)

VALIDATION_ERRORS=0

for file in "${REQUIRED_PYTHON_FILES[@]}"; do
    if [ ! -f "$SCRIPT_DIR/$file" ]; then
        echo "[INSTALL] ✗ Missing: $file"
        VALIDATION_ERRORS=$((VALIDATION_ERRORS + 1))
    else
        echo "[INSTALL] ✓ Found: $file"
    fi
done

# Check prompts directory and files (2-agent system)
if [ ! -d "$SCRIPT_DIR/prompts" ]; then
    echo "[INSTALL] ✗ Missing: prompts/ directory"
    VALIDATION_ERRORS=$((VALIDATION_ERRORS + 1))
else
    echo "[INSTALL] ✓ Found: prompts/ directory"
    
    PROMPT_FILES=(
        "frontier_system_analyzer.txt"
        "frontier_coder_runner.txt"
    )
    
    for file in "${PROMPT_FILES[@]}"; do
        if [ ! -f "$SCRIPT_DIR/prompts/$file" ]; then
            echo "[INSTALL] ✗ Missing: prompts/$file"
            VALIDATION_ERRORS=$((VALIDATION_ERRORS + 1))
        else
            echo "[INSTALL] ✓ Found: prompts/$file"
        fi
    done
fi

# Check examples directory and files
if [ ! -d "$SCRIPT_DIR/examples" ]; then
    echo "[INSTALL] ✗ Missing: examples/ directory"
    VALIDATION_ERRORS=$((VALIDATION_ERRORS + 1))
else
    echo "[INSTALL] ✓ Found: examples/ directory"
    
    EXAMPLE_FILES=(
        "example_scenario_basic_fix.txt"
        "example_scenario_error_recovery.txt"
        "example_scenario_kvm_research.txt"
        "example_scenario_validation_testing.txt"
    )
    
    for file in "${EXAMPLE_FILES[@]}"; do
        if [ ! -f "$SCRIPT_DIR/examples/$file" ]; then
            echo "[INSTALL] ✗ Missing: examples/$file"
            VALIDATION_ERRORS=$((VALIDATION_ERRORS + 1))
        else
            echo "[INSTALL] ✓ Found: examples/$file"
        fi
    done
fi

echo ""

if [ $VALIDATION_ERRORS -gt 0 ]; then
    echo "[INSTALL] ✗✗✗ Validation failed! ✗✗✗"
    echo "[INSTALL] Found $VALIDATION_ERRORS missing file(s)"
    echo ""
    echo "Expected directory structure:"
    echo "  ."
    echo "  ├── aios"
    echo "  ├── aios_main.py"
    echo "  ├── aios_config.py"
    echo "  ├── aios_coordinator.py"
    echo "  ├── coder_runtime.py"
    echo "  ├── llm_client.py"
    echo "  ├── install_aios.sh"
    echo "  ├── prompts/"
    echo "  │   ├── frontier_system_analyzer.txt"
    echo "  │   └── frontier_coder_runner.txt"
    echo "  └── examples/"
    echo "      ├── example_scenario_basic_fix.txt"
    echo "      ├── example_scenario_error_recovery.txt"
    echo "      ├── example_scenario_kvm_research.txt"
    echo "      └── example_scenario_validation_testing.txt"
    echo ""
    exit 1
fi

# ============================================================
#  Create installation directories
# ============================================================

echo "[INSTALL] Creating installation directories..."
sudo mkdir -p "$AIOS_HOME"
sudo mkdir -p "$AIOS_HOME/prompts"
sudo mkdir -p "$AIOS_HOME/examples"
echo "[INSTALL] ✓ Directories created"
echo ""

# ============================================================
#  Copy Python modules (root directory)
# ============================================================

echo "[INSTALL] Installing Python modules..."

for file in "${REQUIRED_PYTHON_FILES[@]}"; do
    if [ "$file" = "aios" ]; then
        continue
    fi
    echo "[INSTALL]   Copying $file..."
    sudo cp "$SCRIPT_DIR/$file" "$AIOS_HOME/"
done

echo "[INSTALL] ✓ Python modules installed"
echo ""

# ============================================================
#  Copy prompt files (prompts/ directory - 2-agent system)
# ============================================================

echo "[INSTALL] Installing Frontier prompts (2-agent system)..."

PROMPT_FILES=(
    "frontier_system_analyzer.txt"
    "frontier_coder_runner.txt"
)

for file in "${PROMPT_FILES[@]}"; do
    echo "[INSTALL]   Copying prompts/$file..."
    sudo cp "$SCRIPT_DIR/prompts/$file" "$AIOS_HOME/prompts/"
done

echo "[INSTALL] ✓ Frontier prompts installed"
echo ""

# ============================================================
#  Copy example scenarios (examples/ directory)
# ============================================================

echo "[INSTALL] Installing example scenarios..."

EXAMPLE_FILES=(
    "example_scenario_basic_fix.txt"
    "example_scenario_error_recovery.txt"
    "example_scenario_kvm_research.txt"
    "example_scenario_validation_testing.txt"
)

for file in "${EXAMPLE_FILES[@]}"; do
    echo "[INSTALL]   Copying examples/$file..."
    sudo cp "$SCRIPT_DIR/examples/$file" "$AIOS_HOME/examples/"
done

echo "[INSTALL] ✓ Example scenarios installed"
echo ""

# ============================================================
#  Install CLI wrapper
# ============================================================

echo "[INSTALL] Installing CLI wrapper..."
echo "[INSTALL]   Copying aios to $BIN_PATH..."
sudo cp "$SCRIPT_DIR/aios" "$BIN_PATH"
sudo chmod +x "$BIN_PATH"
echo "[INSTALL] ✓ CLI wrapper installed and made executable"
echo ""

# ============================================================
#  Create default config file
# ============================================================

if [ ! -f "$AIOS_HOME/.aios_config.json" ]; then
    echo "[INSTALL] Creating default configuration..."
    sudo tee "$AIOS_HOME/.aios_config.json" > /dev/null <<'JSON'
{
  "aios_root": "/usr/local/lib/aios",
  "executor_mode": "local",
  "max_iterations": 5,
  "log_level": "INFO",
  "verbose": false,
  "backup_dir": ".aios/backups",
  "log_dir": ".aios/logs",
  "discovery_dir": ".aios/discovery",
  "llama_model": "/root/gemma-4-26B-A4B-it-ara-abliterated/gemma4-ara-2pass-APEX-Q5_K_M.gguf",
  "llama_grammar": "/root/llama.cpp/grammars/json.gbnf",
  "llama_ctx": 4096,
  "llama_threads": 6
}
JSON
    sudo chmod 644 "$AIOS_HOME/.aios_config.json"
    echo "[INSTALL] ✓ Default configuration created"
else
    echo "[INSTALL] ✓ Configuration file already exists (not overwriting)"
fi
echo ""

# ============================================================
#  Verify installation
# ============================================================

echo "[INSTALL] Verifying installation..."

VERIFY_ERRORS=0

# Verify Python files
for file in "${REQUIRED_PYTHON_FILES[@]}"; do
    if [ "$file" = "aios" ]; then
        if [ ! -f "$BIN_PATH" ]; then
            echo "[INSTALL] ✗ CLI wrapper not installed at $BIN_PATH"
            VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
        else
            echo "[INSTALL] ✓ CLI wrapper: $BIN_PATH"
        fi
    else
        if [ ! -f "$AIOS_HOME/$file" ]; then
            echo "[INSTALL] ✗ Python module not installed: $file"
            VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
        else
            echo "[INSTALL] ✓ Python module: $file"
        fi
    fi
done

# Verify prompt files
for file in "${PROMPT_FILES[@]}"; do
    if [ ! -f "$AIOS_HOME/prompts/$file" ]; then
        echo "[INSTALL] ✗ Prompt not installed: $file"
        VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
    else
        echo "[INSTALL] ✓ Prompt: $file"
    fi
done

# Verify example files
for file in "${EXAMPLE_FILES[@]}"; do
    if [ ! -f "$AIOS_HOME/examples/$file" ]; then
        echo "[INSTALL] ✗ Example not installed: $file"
        VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
    else
        echo "[INSTALL] ✓ Example: $file"
    fi
done

# Check PATH
echo ""
if ! command -v aios &> /dev/null; then
    echo "[INSTALL] ⚠ Warning: 'aios' command not in PATH"
    echo "[INSTALL]   Add to your shell profile (~/.bashrc, ~/.zshrc, etc.):"
    echo "[INSTALL]   export PATH=/usr/local/bin:\$PATH"
else
    echo "[INSTALL] ✓ aios command is in PATH"
fi

# ============================================================
#  Installation complete or failed
# ============================================================

echo ""
echo "[INSTALL] =========================================="

if [ $VERIFY_ERRORS -eq 0 ]; then
    echo "[INSTALL] ✓✓✓ Installation successful! ✓✓✓"
    echo "[INSTALL] =========================================="
    echo ""
    echo "AIOS 2-Agent Frontier System installed successfully!"
    echo ""
    echo "Location: $AIOS_HOME"
    echo "CLI Wrapper: $BIN_PATH"
    echo ""
    echo "Agents:"
    echo "  1. Frontier System Analyzer (plans what to do)"
    echo "  2. Frontier Coder/Runner (executes and validates)"
    echo ""
    echo "Installed files:"
    echo "  Python modules: 5 files"
    echo "  Prompts:        2 files (frontier_system_analyzer.txt, frontier_coder_runner.txt)"
    echo "  Examples:       4 files"
    echo "  Config:         .aios_config.json (edit to customize)"
    echo ""
    echo "Next steps:"
    echo "  1. Edit configuration: $AIOS_HOME/.aios_config.json"
    echo "  2. Set LLAMA_MODEL to your .gguf path"
    echo "  3. Run a test: aios npm test"
    echo "  4. Press Ctrl+\\ to enter AIOS mode and give a goal"
    echo ""
    echo "Examples to learn from:"
    echo "  cat $AIOS_HOME/examples/example_scenario_basic_fix.txt"
    echo "  cat $AIOS_HOME/examples/example_scenario_kvm_research.txt"
    echo ""
    exit 0
else
    echo "[INSTALL] ✗✗✗ Installation failed! ✗✗✗"
    echo "[INSTALL] =========================================="
    echo ""
    echo "Verification failed: $VERIFY_ERRORS error(s)"
    echo ""
    exit 1
fi
